
<?php
echo "Hello world - Admin";

?>